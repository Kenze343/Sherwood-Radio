
        <link rel="stylesheet" type="text/css" href="css/jquery.mCustomScrollbar.css" media="all" /><!-- playlist scroll -->
        <link rel="stylesheet" type="text/css" href="css/classic.css" /><!-- main css file -->
        
        <script src="js/jquery-3.2.1.min.js"></script>
        <script src="js/jquery.mCustomScrollbar.concat.min.js"></script><!-- playlist scroll -->
        <script src="js/jsmediatags.min.js"></script><!-- id3 tags -->
        <script src="js/textscroller.js"></script><!-- scroling title -->
        <script src="js/sharemanager.js"></script><!-- share -->
        <script src="js/radio.js"></script><!-- radio -->
        <script src="js/new.js"></script><!-- main js file -->  
        <script>

            jQuery(document).ready(function($) {
                
                var settings = {
                    instanceName:"player1",
                    sourcePath:"",
                    activePlaylist:"#playlist-radio",
                    activeItem:0,
                    volume:0.5,
                    autoPlay:<?php echo $autoplay; ?>,
                    preload:"auto",
                    randomPlay:false,
                    loopingOn:true,
                    soundCloudAppId:"r4wruADPCq7iqJomagvYpdehvILa2bgE",
                    usePlaylistScroll:true,
                    playlistScrollOrientation:"vertical",
                    playlistScrollTheme:"dark-thin",
                    facebookAppId:"644413448983338",
                    useNumbersInPlaylist: false,
                    playlistItemContent:"title,thumb,description,duration,date",
                    limitDescriptionText:100,
                    useTitleScroll: true,
                    titleScrollSpeed: 1,
                    titleScrollSeparator: "&nbsp;&#42;&#42;&#42;&nbsp;",
                    breakPointArr:"500",
                    enableCors:false,
                };

                $("#hap-wrapper").hap(settings);

            });

        </script>
        <style>
             #hap-wrapper{
                max-width: 500px;
            } 
            .ucartz_bg-black{
                background-color: <?php echo $player_bg; ?>;
            }
            .ucartz_bg-black-img{
                background:transparent;
                background-color: <?php echo $player_bg; ?>;
            }
            .hap-contr-btn svg {
                color: #fff;
            }
            .ucartz_hap-media-title{
                color: #fff !important;
            }
            
        </style>
        
    
        <div id="hap-wrapper" class="hap-classic" style="text-align: center;border-radius: 10px;">
<small style="position: relative;top: 50px;font-size: 8px;text-shadow: 0px 0px 4px rgba(0, 0, 0, 1);z-index: 1004;">
                           <b>
                        <a style="color:#fff;text-decoration: none;" target="_blank" href="https://ucartz.com" title="Ucartz.com">Ucartz.com</a>
                        </b>
                        </small>
            <div class="hap-player-outer">
        
            <div class="hap-player-holder ucartz_bg-black-img">

                <div class="hap-prev-toggle hap-contr-btn ucartz_bg-black">
                    <svg viewBox="0 0 512 512"><path d="M11.5 280.6l192 160c20.6 17.2 52.5 2.8 52.5-24.6V96c0-27.4-31.9-41.8-52.5-24.6l-192 160c-15.3 12.8-15.3 36.4 0 49.2zm256 0l192 160c20.6 17.2 52.5 2.8 52.5-24.6V96c0-27.4-31.9-41.8-52.5-24.6l-192 160c-15.3 12.8-15.3 36.4 0 49.2z"></path></svg>
                </div>
                <div class="hap-playback-toggle hap-contr-btn ucartz_bg-black">
                    <div class="hap-btn hap-btn-play">
                        <svg viewBox="0 0 448 512"><path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z"></path></svg>
                    </div>
                    <div class="hap-btn hap-btn-pause">
                        <svg viewBox="0 0 448 512"><path d="M144 479H48c-26.5 0-48-21.5-48-48V79c0-26.5 21.5-48 48-48h96c26.5 0 48 21.5 48 48v352c0 26.5-21.5 48-48 48zm304-48V79c0-26.5-21.5-48-48-48h-96c-26.5 0-48 21.5-48 48v352c0 26.5 21.5 48 48 48h96c26.5 0 48-21.5 48-48z"></path></svg>
                    </div>
                </div>
                <div class="hap-next-toggle hap-contr-btn ucartz_bg-black">
                    <svg viewBox="0 0 512 512"><path d="M500.5 231.4l-192-160C287.9 54.3 256 68.6 256 96v320c0 27.4 31.9 41.8 52.5 24.6l192-160c15.3-12.8 15.3-36.4 0-49.2zm-256 0l-192-160C31.9 54.3 0 68.6 0 96v320c0 27.4 31.9 41.8 52.5 24.6l192-160c15.3-12.8 15.3-36.4 0-49.2z"></path></svg>
                </div>

                <div class="ucartz_hap-media-title-mask ucartz_bg-black">
                    <div class="ucartz_hap-media-title"></div>
                </div>

                
                <div class="hap-player-controls-right ucartz_bg-black">
               
                    <div class="hap-media-time">
                        <div class="hap-media-time-total">0:00</div>
                        <div class="hap-media-time-separator">&nbsp;&#47;&nbsp;</div>
                        <div class="hap-media-time-current">0:00</div>
                    </div>   

                    <div class="hap-volume-wrapper">
                        <div class="hap-volume-toggle hap-contr-btn" data-tooltip="Volume">
                            <div class="hap-btn hap-btn-volume-up">
                                <svg viewBox="0 0 576 512"><path d="M215.03 71.05L126.06 160H24c-13.26 0-24 10.74-24 24v144c0 13.25 10.74 24 24 24h102.06l88.97 88.95c15.03 15.03 40.97 4.47 40.97-16.97V88.02c0-21.46-25.96-31.98-40.97-16.97zm233.32-51.08c-11.17-7.33-26.18-4.24-33.51 6.95-7.34 11.17-4.22 26.18 6.95 33.51 66.27 43.49 105.82 116.6 105.82 195.58 0 78.98-39.55 152.09-105.82 195.58-11.17 7.32-14.29 22.34-6.95 33.5 7.04 10.71 21.93 14.56 33.51 6.95C528.27 439.58 576 351.33 576 256S528.27 72.43 448.35 19.97zM480 256c0-63.53-32.06-121.94-85.77-156.24-11.19-7.14-26.03-3.82-33.12 7.46s-3.78 26.21 7.41 33.36C408.27 165.97 432 209.11 432 256s-23.73 90.03-63.48 115.42c-11.19 7.14-14.5 22.07-7.41 33.36 6.51 10.36 21.12 15.14 33.12 7.46C447.94 377.94 480 319.54 480 256zm-141.77-76.87c-11.58-6.33-26.19-2.16-32.61 9.45-6.39 11.61-2.16 26.2 9.45 32.61C327.98 228.28 336 241.63 336 256c0 14.38-8.02 27.72-20.92 34.81-11.61 6.41-15.84 21-9.45 32.61 6.43 11.66 21.05 15.8 32.61 9.45 28.23-15.55 45.77-45 45.77-76.88s-17.54-61.32-45.78-76.86z"></path></svg>
                            </div>
                            <div class="hap-btn hap-btn-volume-down">
                                <svg viewBox="0 0 384 512"><path d="M215.03 72.04L126.06 161H24c-13.26 0-24 10.74-24 24v144c0 13.25 10.74 24 24 24h102.06l88.97 88.95c15.03 15.03 40.97 4.47 40.97-16.97V89.02c0-21.47-25.96-31.98-40.97-16.98zm123.2 108.08c-11.58-6.33-26.19-2.16-32.61 9.45-6.39 11.61-2.16 26.2 9.45 32.61C327.98 229.28 336 242.62 336 257c0 14.38-8.02 27.72-20.92 34.81-11.61 6.41-15.84 21-9.45 32.61 6.43 11.66 21.05 15.8 32.61 9.45 28.23-15.55 45.77-45 45.77-76.88s-17.54-61.32-45.78-76.87z"></path></svg>
                            </div>
                            <div class="hap-btn hap-btn-volume-off">
                                <svg viewBox="0 0 640 512"><path d="M633.82 458.1l-69-53.33C592.42 360.8 608 309.68 608 256c0-95.33-47.73-183.58-127.65-236.03-11.17-7.33-26.18-4.24-33.51 6.95-7.34 11.17-4.22 26.18 6.95 33.51 66.27 43.49 105.82 116.6 105.82 195.58 0 42.78-11.96 83.59-33.22 119.06l-38.12-29.46C503.49 318.68 512 288.06 512 256c0-63.09-32.06-122.09-85.77-156.16-11.19-7.09-26.03-3.8-33.12 7.41-7.09 11.2-3.78 26.03 7.41 33.13C440.27 165.59 464 209.44 464 256c0 21.21-5.03 41.57-14.2 59.88l-39.56-30.58c3.38-9.35 5.76-19.07 5.76-29.3 0-31.88-17.53-61.33-45.77-76.88-11.58-6.33-26.19-2.16-32.61 9.45-6.39 11.61-2.16 26.2 9.45 32.61 11.76 6.46 19.12 18.18 20.4 31.06L288 190.82V88.02c0-21.46-25.96-31.98-40.97-16.97l-49.71 49.7L45.47 3.37C38.49-2.05 28.43-.8 23.01 6.18L3.37 31.45C-2.05 38.42-.8 48.47 6.18 53.9l588.36 454.73c6.98 5.43 17.03 4.17 22.46-2.81l19.64-25.27c5.41-6.97 4.16-17.02-2.82-22.45zM32 184v144c0 13.25 10.74 24 24 24h102.06l88.97 88.95c15.03 15.03 40.97 4.47 40.97-16.97V352.6L43.76 163.84C36.86 168.05 32 175.32 32 184z"></path></svg>
                            </div>
                        </div>
                        <div class="hap-volume-seekbar">
                             <div class="hap-volume-bg">
                                <div class="hap-volume-level"></div>
                             </div>
                        </div>
                    </div>

                    <div class="hap-playlist-toggle hap-contr-btn" data-tooltip="Playlist">
                        <svg viewBox="0 0 512 512"><path d="M149.333 216v80c0 13.255-10.745 24-24 24H24c-13.255 0-24-10.745-24-24v-80c0-13.255 10.745-24 24-24h101.333c13.255 0 24 10.745 24 24zM0 376v80c0 13.255 10.745 24 24 24h101.333c13.255 0 24-10.745 24-24v-80c0-13.255-10.745-24-24-24H24c-13.255 0-24 10.745-24 24zM125.333 32H24C10.745 32 0 42.745 0 56v80c0 13.255 10.745 24 24 24h101.333c13.255 0 24-10.745 24-24V56c0-13.255-10.745-24-24-24zm80 448H488c13.255 0 24-10.745 24-24v-80c0-13.255-10.745-24-24-24H205.333c-13.255 0-24 10.745-24 24v80c0 13.255 10.745 24 24 24zm-24-424v80c0 13.255 10.745 24 24 24H488c13.255 0 24-10.745 24-24V56c0-13.255-10.745-24-24-24H205.333c-13.255 0-24 10.745-24 24zm24 264H488c13.255 0 24-10.745 24-24v-80c0-13.255-10.745-24-24-24H205.333c-13.255 0-24 10.745-24 24v80c0 13.255 10.745 24 24 24z"></path></svg>
                    </div>

                </div>  
             
            </div>  

            

        </div>

        <div class="hap-preloader"></div>

        </div> 

        <!-- PLAYLIST LIST -->
        <div id="hap-playlist-list">

            <div id="playlist-radio">

                 <div class="hap-playlist-item" data-type="shoutcast" data-version="2" data-path="<?php echo $stream_url; ?>" data-title="SHOUTCAST VERSION 2 EXAMPLE" data-thumb="your thumb here"></div>
               
            </div>  
             
        </div>