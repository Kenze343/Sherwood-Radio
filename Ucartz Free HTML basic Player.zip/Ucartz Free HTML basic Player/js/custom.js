$(document).ready(function(){
		  $(".switchBtn").click(function(){
		  if($(".switchBtn").hasClass("active")){
			$(".togglePrice").text("4800INR");
			}
			else {
			$(".togglePrice").text("2000INR");
			}
		  });
		});