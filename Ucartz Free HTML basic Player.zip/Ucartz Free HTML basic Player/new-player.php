
<!DOCTYPE html>
<html lang="en">
<head>
   <title>Free Shoutcast Icecast Web Player</title>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">

   <link rel="stylesheet" href="css/bootstrap.min.css">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
   <link rel="stylesheet" href="css/classic-player.css">

   <link rel="icon" href="img/favicon.ico" type="image/icon" sizes="16x16">
   
</head>
<body>


  <!--  here you need to enter header -->   

<!-- banner section start here  -->
<section class="ucartz_gradientBG ucartz_p-t-100 ucartz_p-b-80">
<div class="row" style="margin-top: 100px;">
   <div class="col-sm-12 col-sm-12">

      <h1 style="text-align: center; color: #fff;">Free Shoutcast Icecast Web Player</h1>
   </div>
</div> 
</section>
<!-- banner section end here  -->
<section id="ucartz_player_display">
   <div class="container" style="">
      <?php
  
  /* here you can add the url */
      $stream_url = 'https://centova47.instainternet.com/proxy/detentefm?mp=/stream';
  /* here you can make the player auto play or not by giving true/false */
      $autoplay = "true";
  /* here you can make the player background color by giving html color code */
    $player_bg = "#000";
     
     include 'player-templates/classic-player1.php'; 
  
  ?>
   
</div>
</section>

<!-- Add footer here -->

<div class="ucartz_copyright">Copyright 2020 - 2021 © <a href="http://www.ucartz.com" target="_blank"><strong>Ucartz Online</strong></a>. All Rights Reserved.</div>
<script>
  
</script>

</body>
</html>